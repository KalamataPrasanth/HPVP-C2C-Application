import { useState } from "react";
import "./BuyPage.css";
import dummyImage from "../assets/dummy.jpg"; // 

const items = [
  {
    id: 1,
    name: "Laptop",
    description: "High-performance laptop with SSD storage.",
    image: dummyImage,
    seller: {
      name: "Prasanth",
      staffNo: "12345",
      telephone: "012-3456789",
      mobile: "9876543210",
      email: "john.doe@example.com",
      address: "123 Street, Vizag",
    },
    details: "Core i7, 16GB RAM, 512GB SSD. Works perfectly!",
    price: "25000",
  },
  {
    id: 2,
    name: "Office Chair",
    description: "Ergonomic office chair, barely used.",
    image: dummyImage,
    seller: {
      name: "Rajesh",
      staffNo: "67890",
      telephone: "098-7654321",
      mobile: "1234567890",
      email: "jane.smith@example.com",
      address: "456 Avenue, Vizag",
    },
    details: "Adjustable height, lumbar support, black leather.",
    price: "1500",
  },
  {
  id: 3,
    name: "Monitor",
    description: "4k Monitor, 120hz refresh rate",
    image: dummyImage,
    seller: {
      name: "Rohit",
      staffNo: "12345",
      telephone: "012-3456789",
      mobile: "9876543210",
      email: "john.doe@example.com",
      address: "123 Street, Vizag",
    },
    details: "4K resolution, 120hz refresh rate. Works hevenly!",
    price: "16000",
  },
  {
    id: 4,
    name: "Study Table",
    description: "Quality Wood, Ocassionally used",
    image: dummyImage,
    seller: {
      name: "Sasi",
      staffNo: "67890",
      telephone: "098-7654321",
      mobile: "1234567890",
      email: "jane.smith@example.com",
      address: "456 Avenue, Vizag",
    },
    details: "Adjustable height, fine quality wood, termite free.",
    price: "3000",
  },
  {

    id: 5,
    name: "House",
    description: "House for Sale, see details",
    image: dummyImage,
    seller: {
      name: "Sai",
      staffNo: "12345",
      telephone: "012-3456789",
      mobile: "9876543210",
      email: "john.doe@example.com",
      address: "123 Street, Vizag",
    },
    details: "East facing, well ventilated, fully furnished",
    price: "6600000",
  },
  {
    id: 6,
    name: "Bike",
    description: "Royal Enfield Classic 350c",
    image: dummyImage,
    seller: {
      name: "Likhit",
      staffNo: "67890",
      telephone: "098-7654321",
      mobile: "1234567890",
      email: "jane.smith@example.com",
      address: "456 Avenue, Vizag",
    },
    details: "2015 Model Royal Enfield, 20000km only, All papers available",
    price: "45000",
  },
];

const BuyPage = () => {
  const [selectedItem, setSelectedItem] = useState(null);

  return (
    <div className="buy-page">
      <h1>Buy Items</h1>
      <div className="item-grid">
        {items.map((item) => (
          <div key={item.id} className="item-card">
            <img src={item.image} alt={item.name} className="item-image" />
            <h3>{item.name}</h3>
            <p>{item.description}</p>
            <button onClick={() => setSelectedItem(item)}>Know More</button>
          </div>
        ))}
      </div>

      {selectedItem && (
        <div className="modal-overlay" onClick={() => setSelectedItem(null)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="close-btn" onClick={() => setSelectedItem(null)}>X</button>
            <h2 className="selected-item">{selectedItem.name}</h2>
            <div className="modal-details">
              <div className="modal-item-details">
                <h3>Item Details</h3>
                <img src={selectedItem.image} alt={selectedItem.name} className="modal-image" />
                <div className="modal-item-description">
                  <p><strong>Description:</strong> {selectedItem.details}</p>
                  <p><strong>Price:</strong> {selectedItem.price}</p>
                </div>
              </div>
              <div className="seller-details">
                <h3>Seller Details</h3>
                <div className="modal-seller-details">
                  <p><strong>Name:</strong> {selectedItem.seller.name}</p>
                  <p><strong>Staff No:</strong> {selectedItem.seller.staffNo}</p>
                  <p><strong>Phone:</strong> {selectedItem.seller.telephone}</p>
                  <p><strong>Mobile:</strong> {selectedItem.seller.mobile}</p>
                  <p><strong>Email:</strong> {selectedItem.seller.email}</p>
                  <p><strong>Address:</strong> {selectedItem.seller.address}</p>
                </div>
              </div>
            </div>
            
          </div>
        </div>
      )}
    </div>
  );
};

export default BuyPage;
