import axios from "axios";

const API_URL = "http://localhost:5000/api/products";

// adding products
export const addProduct = async (productData) => {
    try{
        const formData = new FormData();
        console.log("Product Data: ", productData);

        for(const key in productData){
            formData.append(key, productData[key]);
        }

        for(let [key, value] of formData.entries()){
            console.log(key, value);
        }

        const response = await axios.post(API_URL, formData, {
            headers: {
                "Content-Type": "multipart/form-data",
            },
        });
        return response.data;
    }catch(error){
        console.log("Error Adding product: ", error);
        throw error;
    }
};

//fetching products
export const getProducts = async () => {
    try{
      const response = await axios.get(API_URL);
      return response.data
    }catch(error){
      console.error("Error fetching products: ", error);
      throw error;
    }
  };

//deleting porducts
export const deleteProduct = async (id) => {
    try{
        const response = await axios.delete(`${API_URL}/${id}`);
        return response.data
    }catch(error){
        console.error("Error deleting product: ", error);
        throw error;
    }
};

//updating products
export const updateProduct = async (id, updatedData) => {
    try {
        const formData = new FormData();
        for (const jey in updatedData){
            formData.append(key, updatedData[key]);
        }
        const response = await axios.put(`${API_URL}/${id}`, formData, {
            headers: {
                "Content-Type": "multipart/form-data",
            }
        });
        return response.data;
    } catch (error) {
        console.error("Error updating product:", error);
        throw error;
    }
};
