import { useState } from 'react';
import './LoginModal.css';

const LoginModal = ({ onClose, onLogin }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        if (username === 'admin' && password === 'admin') {
            onLogin();
        } else {
            setError('Invalid credentials. Try again.');
        }
    };

    return (
        <div className="modal-overlay">
            <div className="login-modal">
                <h2>Login</h2>
                <form className='login-form' onSubmit={handleSubmit}>
                    <div className="input-container">
                        <input 
                            type="text" 
                            placeholder="username" 
                            value={username} 
                            onChange={(e) => setUsername(e.target.value)}
                            autoFocus
                            required 
                        />
                    </div>
                    <div className="input-container">
                        <input 
                            id='password'
                            type="password" 
                            placeholder="Password" 
                            value={password} 
                            onChange={(e) => setPassword(e.target.value)} 
                            required 
                        />
                    </div>
                    
                    {error && <p className="error">{error}</p>}
                    <button className='login-btn' type="submit">Login</button>
                </form>
                <button className="close-btn" onClick={onClose}>x</button>
            </div>
        </div>
    );
};

export default LoginModal;
