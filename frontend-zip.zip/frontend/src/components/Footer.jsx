import "./Footer.css";

const Footer = () => {
  return (
    <footer className="footer">
      <p>&copy; 2025 HPVP Vizag. All rights reserved.</p>
    </footer>
  );
};

export default Footer;